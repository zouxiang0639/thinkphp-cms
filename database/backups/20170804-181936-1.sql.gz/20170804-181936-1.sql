-- -----------------------------
-- SentCMS MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : thinkphp-cms
-- 
-- Part : #1
-- Date : 2017-08-04 18:19:36
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `tp_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `tp_action_log`;
CREATE TABLE `tp_action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `role_id` int(11) NOT NULL COMMENT '执行用户ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `log` longtext NOT NULL COMMENT '日志备注',
  `log_url` varchar(100) NOT NULL COMMENT '执行的URL',
  `username` varchar(100) NOT NULL COMMENT '执行者名称',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='行为日志表';

-- -----------------------------
-- Records of `tp_action_log`
-- -----------------------------
INSERT INTO `tp_action_log` VALUES ('1', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/publics/login.html', 'admin');
INSERT INTO `tp_action_log` VALUES ('2', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/publics/login.html', 'admin');
INSERT INTO `tp_action_log` VALUES ('3', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/publics/login.html', 'admin');
INSERT INTO `tp_action_log` VALUES ('4', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/Publics/checkLogin.html', 'admin');
INSERT INTO `tp_action_log` VALUES ('5', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/publics/login.html', 'admin');
INSERT INTO `tp_action_log` VALUES ('6', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/publics/login.html', 'admin');
INSERT INTO `tp_action_log` VALUES ('7', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/publics/login.html', 'admin');
INSERT INTO `tp_action_log` VALUES ('8', '后台登录', '0', '1', '2130706433', '管理员 admin 进入后台了,', '/manage/publics/login.html', 'admin');

-- -----------------------------
-- Table structure for `tp_admin`
-- -----------------------------
DROP TABLE IF EXISTS `tp_admin`;
CREATE TABLE `tp_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL COMMENT '用户名',
  `admin_password` char(32) NOT NULL COMMENT '用户密码',
  `login_priv` tinyint(1) NOT NULL DEFAULT '1' COMMENT '登录权限: 1,授权 2,关闭',
  `last_login_ip` int(11) NOT NULL COMMENT '最后登录IP',
  `last_login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后登录时间',
  `admin_email` varchar(50) NOT NULL COMMENT '管理员邮箱',
  `comment` varchar(255) NOT NULL COMMENT '管理员介绍',
  `sex` tinyint(1) NOT NULL COMMENT '性别:1,男 2,女',
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `code` varchar(50) NOT NULL COMMENT '管理员编号',
  `role` varchar(100) NOT NULL COMMENT '角色',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `admin_name` (`admin_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员表';

-- -----------------------------
-- Records of `tp_admin`
-- -----------------------------
INSERT INTO `tp_admin` VALUES ('1', 'admin', 'ad7f80935768e7327adbcefe89c70d87', '1', '0', '2017-08-03 13:48:45', '', '', '0', '', '', '', '2017-04-30 12:13:50', '2017-08-03 13:48:45');

-- -----------------------------
-- Table structure for `tp_auth_access`
-- -----------------------------
DROP TABLE IF EXISTS `tp_auth_access`;
CREATE TABLE `tp_auth_access` (
  `role_id` int(11) unsigned NOT NULL COMMENT '角色ID',
  `menu_id` int(11) unsigned NOT NULL COMMENT '后台菜单ID',
  `rule_name` varchar(255) NOT NULL COMMENT '规则唯一英文标识,全小写',
  `type` varchar(30) NOT NULL COMMENT '权限规则分类，请加应用前缀,如admin_',
  KEY `role_id` (`role_id`),
  KEY `rule_name` (`rule_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限授权表';


-- -----------------------------
-- Table structure for `tp_auth_role`
-- -----------------------------
DROP TABLE IF EXISTS `tp_auth_role`;
CREATE TABLE `tp_auth_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '角色名称',
  `status` tinyint(1) unsigned NOT NULL COMMENT '状态: 1,授权 2,关闭',
  `remark` varchar(255) NOT NULL COMMENT '备注',
  `listorder` tinyint(4) NOT NULL COMMENT '排序字段',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- -----------------------------
-- Records of `tp_auth_role`
-- -----------------------------
INSERT INTO `tp_auth_role` VALUES ('1', '超级管理员', '1', '超级管理员角色可以操作系统所有操作', '0', '2017-04-30 12:13:50', '');

-- -----------------------------
-- Table structure for `tp_auth_role_user`
-- -----------------------------
DROP TABLE IF EXISTS `tp_auth_role_user`;
CREATE TABLE `tp_auth_role_user` (
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `user_id` tinyint(1) NOT NULL COMMENT '用户ID',
  KEY `role_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色中间表';


-- -----------------------------
-- Table structure for `tp_banner`
-- -----------------------------
DROP TABLE IF EXISTS `tp_banner`;
CREATE TABLE `tp_banner` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `picture` varchar(100) NOT NULL COMMENT '图片',
  `links` varchar(150) NOT NULL COMMENT '链接',
  `groups` tinyint(1) NOT NULL DEFAULT '1' COMMENT '所属组',
  `comment` varchar(255) NOT NULL COMMENT '描述',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='幻灯片表';


-- -----------------------------
-- Table structure for `tp_category`
-- -----------------------------
DROP TABLE IF EXISTS `tp_category`;
CREATE TABLE `tp_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `parent_id` smallint(5) unsigned NOT NULL COMMENT '父级ID',
  `template_group` tinyint(4) NOT NULL DEFAULT '1' COMMENT '模版模型',
  `template_default` varchar(100) NOT NULL COMMENT '默认模版',
  `template_info` varchar(100) NOT NULL COMMENT '详情模板',
  `display` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示: 0,删除, 1,所有人可见 2,不可见 3,管理员可见',
  `list_row` tinyint(4) NOT NULL COMMENT '每页行数',
  `sort` int(10) NOT NULL COMMENT '排序',
  `comment` varchar(255) NOT NULL COMMENT '描述',
  `keywords` varchar(255) NOT NULL COMMENT '关键字',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `content` longtext NOT NULL COMMENT '文章内容',
  `photos` longtext NOT NULL COMMENT '相册图集',
  `picture` varchar(100) NOT NULL COMMENT '缩率图',
  `path` varchar(255) NOT NULL DEFAULT '0' COMMENT '导航路由',
  `extend` longtext NOT NULL COMMENT '扩展属性内容',
  `links` varchar(255) NOT NULL COMMENT '外部链接',
  `data_extended_id` smallint(6) NOT NULL COMMENT '数据扩展ID',
  `fields_extended_id` smallint(6) NOT NULL COMMENT '字段扩展ID',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='导航表';

-- -----------------------------
-- Records of `tp_category`
-- -----------------------------
INSERT INTO `tp_category` VALUES ('1', 'asdas', '0', '2', 'article', 'info', '1', '10', '0', '', '', '', '', '', '', '0', '', '', '0', '0', '2017-07-12 11:02:10', '2017-07-12 11:02:10');

-- -----------------------------
-- Table structure for `tp_configure`
-- -----------------------------
DROP TABLE IF EXISTS `tp_configure`;
CREATE TABLE `tp_configure` (
  `configure_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `configure_name` varchar(100) NOT NULL COMMENT '配置名称',
  `configure_value` varchar(255) NOT NULL COMMENT '配置默认值',
  `form_type` varchar(100) NOT NULL DEFAULT 'text' COMMENT '表单类型',
  `groups` tinyint(4) NOT NULL DEFAULT '1' COMMENT '所属组',
  `comment` varchar(255) NOT NULL COMMENT '描述',
  PRIMARY KEY (`configure_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='配置管理表';

-- -----------------------------
-- Records of `tp_configure`
-- -----------------------------
INSERT INTO `tp_configure` VALUES ('1', '网站标题', 'title', '', 'text', '1', '（网站标题前台显示标题）');
INSERT INTO `tp_configure` VALUES ('2', '网站描述', 'description', '', 'textarea', '1', '（网站搜索引擎描述）');
INSERT INTO `tp_configure` VALUES ('3', '网站关键字', 'keywords', '', 'textarea', '1', '（网站搜索引擎关键字） 多个用 ( , )隔开');
INSERT INTO `tp_configure` VALUES ('4', '网站备案号', 'icp', '', 'text', '1', '（设置在网站底部显示的备案号，如“沪ICP备12007941号-2）');
INSERT INTO `tp_configure` VALUES ('5', '默认图片', 'default_picture', '', 'text', '1', '网站默认图片');
INSERT INTO `tp_configure` VALUES ('6', 'SMTP服务器', 'smtp_host', '', 'text', '2', '');
INSERT INTO `tp_configure` VALUES ('7', 'SMTP用户名', 'smtp_user', '', 'text', '2', '');
INSERT INTO `tp_configure` VALUES ('8', 'SMTP密码', 'smtp_pass', '', 'text', '2', '');
INSERT INTO `tp_configure` VALUES ('9', 'SMTP端口', 'smtp_port', '', 'text', '2', '');
INSERT INTO `tp_configure` VALUES ('10', '发件邮箱', 'send_email', '', 'text', '2', '');
INSERT INTO `tp_configure` VALUES ('11', '发件名称', 'sender_name', '', 'text', '2', '');

-- -----------------------------
-- Table structure for `tp_extended`
-- -----------------------------
DROP TABLE IF EXISTS `tp_extended`;
CREATE TABLE `tp_extended` (
  `extended_id` int(11) NOT NULL AUTO_INCREMENT,
  `input_type` varchar(100) NOT NULL COMMENT '表单类型',
  `input_value` varchar(255) NOT NULL COMMENT '表单默认值',
  `comment` varchar(255) NOT NULL COMMENT '描述',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `group` tinyint(1) NOT NULL DEFAULT '1' COMMENT '组类型',
  `parent_id` smallint(6) NOT NULL COMMENT '父级ID',
  `name` varchar(100) NOT NULL COMMENT '字段或数据库名称',
  `mysql_fields_type` smallint(6) NOT NULL COMMENT '数据库字段类型',
  `mysql_fields_length` varchar(50) NOT NULL COMMENT '数据库字段长度',
  `mysql_fields_default` varchar(50) NOT NULL COMMENT '数据库字段默认值',
  `sort` smallint(6) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`extended_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='字段扩展表';


-- -----------------------------
-- Table structure for `tp_file`
-- -----------------------------
DROP TABLE IF EXISTS `tp_file`;
CREATE TABLE `tp_file` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(100) NOT NULL COMMENT '路由',
  `hash` varchar(150) NOT NULL COMMENT 'hash1',
  `groups` tinyint(1) NOT NULL DEFAULT '1' COMMENT '所属组: 1,image 2,file 3,video',
  `name` varchar(150) NOT NULL COMMENT '文件名称',
  PRIMARY KEY (`file_id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件上传库表';


-- -----------------------------
-- Table structure for `tp_fragment`
-- -----------------------------
DROP TABLE IF EXISTS `tp_fragment`;
CREATE TABLE `tp_fragment` (
  `fragment_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `links` varchar(150) NOT NULL COMMENT '链接',
  `picture` varchar(150) NOT NULL COMMENT '缩率图',
  `comment` varchar(255) NOT NULL COMMENT '简介',
  `content` longtext NOT NULL COMMENT '模版类型',
  PRIMARY KEY (`fragment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='信息碎片表';


-- -----------------------------
-- Table structure for `tp_info`
-- -----------------------------
DROP TABLE IF EXISTS `tp_info`;
CREATE TABLE `tp_info` (
  `info_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `visiting` int(11) NOT NULL COMMENT '访问量',
  `category_id` smallint(6) NOT NULL COMMENT '分类导航ID',
  `display` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示: 0,删除, 1,所有人可见 2,不可见 3,管理员可见',
  `sort` int(10) NOT NULL COMMENT '排序',
  `comment` varchar(255) NOT NULL COMMENT '描述',
  `keywords` varchar(255) NOT NULL COMMENT '关键字',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `content` longtext NOT NULL COMMENT '文章内容',
  `photos` longtext NOT NULL COMMENT '相册图集',
  `picture` varchar(100) NOT NULL COMMENT '缩率图',
  `recommendation` varchar(100) NOT NULL COMMENT '推荐',
  `extend` longtext NOT NULL COMMENT '扩展属性内容',
  `links` varchar(255) NOT NULL COMMENT '外部链接',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`info_id`),
  KEY `category_id` (`category_id`),
  KEY `display` (`display`),
  KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='信息表';

-- -----------------------------
-- Records of `tp_info`
-- -----------------------------
INSERT INTO `tp_info` VALUES ('1', 'qwrqwr', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:06', '2017-07-12 14:20:13');
INSERT INTO `tp_info` VALUES ('2', 'qwrqw', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:17', '2017-07-12 14:20:21');
INSERT INTO `tp_info` VALUES ('3', 'qwrqw', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:24', '2017-07-12 14:20:28');
INSERT INTO `tp_info` VALUES ('4', 'qwrqwr', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:31', '2017-07-12 14:20:36');
INSERT INTO `tp_info` VALUES ('5', 'qwrqwr', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:31', '2017-07-12 14:20:40');
INSERT INTO `tp_info` VALUES ('6', 'qwrqwr', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:31', '2017-07-12 14:20:43');
INSERT INTO `tp_info` VALUES ('7', 'qwrqwr', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:31', '2017-07-12 14:20:47');
INSERT INTO `tp_info` VALUES ('8', 'wqeqwe', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:53', '2017-07-12 14:20:56');
INSERT INTO `tp_info` VALUES ('9', 'wqeqwe', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:53', '2017-07-12 14:21:00');
INSERT INTO `tp_info` VALUES ('10', 'wqeqwe', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:53', '2017-07-12 14:21:04');
INSERT INTO `tp_info` VALUES ('11', 'wqeqwe', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:53', '2017-07-12 14:21:10');
INSERT INTO `tp_info` VALUES ('12', 'wqeqwe', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:53', '2017-07-12 14:21:15');
INSERT INTO `tp_info` VALUES ('13', 'wqeqwe', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:53', '2017-07-12 14:21:22');
INSERT INTO `tp_info` VALUES ('14', 'wqeqwe', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:53', '2017-07-12 14:21:25');
INSERT INTO `tp_info` VALUES ('15', 'sadas', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:33', '2017-07-12 14:21:38');
INSERT INTO `tp_info` VALUES ('16', 'sadas', '0', '1', '1', '0', '', '', '', '', '', '', '', '', '', '2017-07-12 02:07:33', '2017-07-12 14:21:41');

-- -----------------------------
-- Table structure for `tp_menu`
-- -----------------------------
DROP TABLE IF EXISTS `tp_menu`;
CREATE TABLE `tp_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '标题',
  `parent_id` smallint(5) unsigned NOT NULL COMMENT '父级ID',
  `app` char(20) NOT NULL COMMENT '应用名称app',
  `model` char(20) NOT NULL COMMENT '控制器',
  `action` char(20) NOT NULL COMMENT '操作名称',
  `url_param` char(50) NOT NULL COMMENT 'url参数',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '菜单类型: 0,只作为菜单 1,权限认证+菜单',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态: 0,不显示 1,显示',
  `icon` varchar(50) NOT NULL COMMENT '菜单图标',
  `remark` varchar(255) NOT NULL COMMENT '备注',
  `list_order` smallint(6) NOT NULL DEFAULT '0' COMMENT '排序',
  `rule_param` varchar(255) NOT NULL COMMENT '验证规则',
  `request` varchar(255) NOT NULL COMMENT '请求方式（日志生成）',
  `log_rule` varchar(255) NOT NULL COMMENT '日志规则',
  `nav_id` int(11) NOT NULL COMMENT '前端导航ID',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `model` (`model`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COMMENT='幻灯片表';

-- -----------------------------
-- Records of `tp_menu`
-- -----------------------------
INSERT INTO `tp_menu` VALUES ('1', '系统管理', '0', 'manage', 'system', 'default', '', '0', '1', '', '', '0', '', 'POST', '{name}', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('2', '权限管理', '1', 'manage', 'auth', 'default', '', '0', '1', 'fa-group', '1', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('3', '角色管理', '2', 'manage', 'auth', 'role', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('4', '角色增加', '3', 'manage', 'auth', 'roleAdd', '', '1', '0', '', '', '0', '', '', '{id}', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('5', '角色编辑', '3', 'manage', 'auth', 'roleEdit', '', '1', '0', '', 'asdas', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('6', '角色删除', '3', 'manage', 'auth', 'roleDelete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('7', '角色授权', '3', 'manage', 'auth', 'authorize', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('8', '行为日志', '2', 'manage', 'auth', 'log', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('9', '查看日志', '8', 'manage', 'auth', 'viewLog', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('10', '清空日志', '8', 'manage', 'auth', 'clear', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('11', '管理员管理', '1', 'manage', 'admin', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('12', '用户列表', '11', 'manage', 'admin', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('13', '用户增加', '11', 'manage', 'admin', 'add', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('14', '用户修改', '11', 'manage', 'admin', 'edit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('15', '用户删除', '11', 'manage', 'admin', 'delete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('16', '用户权限设置', '11', 'manage', 'admin', 'privates', '', '1', '0', '', '设置用户登录后台权限设置', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('17', '修改密码', '11', 'manage', 'admin', 'editPassword', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('18', '重置管理员密码', '11', 'manage', 'admin', 'resetPassword', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('19', '配置管理', '1', 'manage', 'configure', 'defaule', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('20', '基本配置', '19', 'manage', 'configure', 'basicSettings', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('21', '邮箱配置', '19', 'manage', 'configure', 'emailSettings', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('22', '修改配置', '19', 'manage', 'configure', 'configBuilder', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('23', '内容管理', '0', 'manage', 'article', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('24', '信息管理', '23', 'manage', 'info', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('25', '信息列表', '24', 'manage', 'info', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('26', '信息增加', '24', 'manage', 'info', 'add', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('27', '信息创建', '24', 'manage', 'info', 'create', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('28', '信息编辑', '24', 'manage', 'info', 'edit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('29', '信息更新', '24', 'manage', 'info', 'update', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('30', '信息删除', '24', 'manage', 'info', 'delete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('31', '信息排序', '24', 'manage', 'info', 'sort', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('32', '导航目录', '23', 'manage', 'category', 'default', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('33', '其他管理', '0', 'manage', 'other', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('34', '幻灯片管理', '33', 'manage', 'banner', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('35', '幻灯片列表', '34', 'manage', 'banner', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('36', '幻灯片增加', '34', 'manage', 'banner', 'add', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('37', '幻灯片修改', '34', 'manage', 'banner', 'edit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('38', '幻灯片更新', '34', 'manage', 'banner', 'update', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('39', '幻灯片删除', '34', 'manage', 'banner', 'delete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('40', '信息碎片管理', '33', 'manage', 'fragment', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('41', '碎片列表', '40', 'manage', 'fragment', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('42', '碎片增加', '40', 'manage', 'fragment', 'add', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('43', '碎片修改', '40', 'manage', 'fragment', 'edit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('44', '碎片更新', '40', 'manage', 'fragment', 'update', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('45', '碎片删除', '40', 'manage', 'fragment', 'delete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('46', '文件管理', '33', 'manage', 'file', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('47', '文件列表', '46', 'manage', 'file', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('48', '扩展工具', '0', 'manage', 'extendedTool', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('49', '菜单管理', '48', 'manage', 'auth', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('50', '菜单列表', '49', 'manage', 'auth', 'menu', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('51', '菜单增加', '49', 'manage', 'auth', 'menuAdd', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('52', '菜单修改', '49', 'manage', 'auth', 'menuEdit', '', '1', '0', '', '', '0', '', 'POST', '我的ID是{id} 记入的目录{name}', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('53', '菜单删除', '49', 'manage', 'auth', 'menuDelete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('54', '菜单排序', '49', 'manage', 'auth', 'menuOrder', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('55', '配置属性', '48', 'manage', 'configure', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('56', '配置属性列表', '55', 'manage', 'configure', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('57', '属性添加', '55', 'manage', 'configure', 'add', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('58', '属性修改', '55', 'manage', 'configure', 'edit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('59', '属性更新', '55', 'manage', 'configure', 'update', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('60', '配置删除', '55', 'manage', 'configure', 'delete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('61', '模版文件管理', '48', 'manage', 'template', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('62', '模版文件列表', '61', 'manage', 'template', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('63', '模版文件添加', '61', 'manage', 'template', 'add', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('64', '模版文件修改', '61', 'manage', 'template', 'edit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('65', '模版文件更新', '61', 'manage', 'template', 'update', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('66', '前端分类管理', '48', 'manage', 'category', 'default', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('67', '分类列表', '66', 'manage', 'category', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('68', '分类增加', '66', 'manage', 'category', 'add', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('69', '分类修改', '66', 'manage', 'category', 'edit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('70', '分类删除', '66', 'manage', 'category', 'delete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('71', '分类更新', '66', 'manage', 'category', 'update', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('72', '分类排序', '66', 'manage', 'category', 'sort', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('73', '数据扩展', '48', 'manage', 'extended', 'default', '', '0', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('74', '数据扩展列表', '73', 'manage', 'extended', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('75', '数据扩展增加', '73', 'manage', 'extended', 'index', '', '1', '1', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('76', '更新扩展', '73', 'manage', 'extended', 'update', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('77', '删除扩展', '73', 'manage', 'extended', 'delete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('78', '数据类型修改', '73', 'manage', 'extended', 'dataTypeEdit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('79', '字段类型修改', '73', 'manage', 'extended', 'fieldsTypeEdit', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('80', '删除数据库字段', '73', 'manage', 'extended', 'mysqlFieldsDelete', '', '1', '0', '', '', '0', '', '', '', '0', '2017-04-30 12:13:51', '');
INSERT INTO `tp_menu` VALUES ('81', 'asdas', '32', 'manage', 'info', 'index', 'id=1', '1', '1', '', '', '0', '{id}==1', '', '', '1', '2017-07-12 11:02:10', '2017-07-12 11:02:10');

-- -----------------------------
-- Table structure for `tp_migrations`
-- -----------------------------
DROP TABLE IF EXISTS `tp_migrations`;
CREATE TABLE `tp_migrations` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tp_migrations`
-- -----------------------------
INSERT INTO `tp_migrations` VALUES ('20170331035336', 'CreateAdmin', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170331150945', 'CreateCategory', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170331235600', 'CreateInfo', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401001805', 'CreateTemplate', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401003221', 'CreateFragment', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401003941', 'CreateFile', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401011147', 'CreateExtended', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401014106', 'CreateConfigure', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401020829', 'CreateBanner', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401022414', 'CreateMenu', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401031359', 'CreateAuthAccess', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401032433', 'CreateAuthRole', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401033535', 'CreateAuthRoleUser', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');
INSERT INTO `tp_migrations` VALUES ('20170401034122', 'CreateActionLog', '2017-04-30 12:13:50', '2017-04-30 12:13:50', '0');

-- -----------------------------
-- Table structure for `tp_template`
-- -----------------------------
DROP TABLE IF EXISTS `tp_template`;
CREATE TABLE `tp_template` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `group` tinyint(4) NOT NULL DEFAULT '1' COMMENT '模版分组模型: 1,单页模型 2,信息模型',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '模版类型: 1,分类页面 2,信息内页 3,通用页面',
  `template_file` varchar(100) NOT NULL COMMENT '模版文件',
  PRIMARY KEY (`template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='模版表';

-- -----------------------------
-- Records of `tp_template`
-- -----------------------------
INSERT INTO `tp_template` VALUES ('1', '单页模版', '1', '1', 'article');
INSERT INTO `tp_template` VALUES ('2', '信息内页模版', '2', '2', 'info');
